import express from 'express';
import cors from 'cors';
import cron from 'node-cron';
import yahooFinance from 'yahoo-finance2';
import { getRepository, getUser, createUser, updateUser, getUsers, getUsersByIp } from './services/storage.js';
import { updateMarketData, fetchHistory } from './services/fetcher.js';
import { calculateRSI, calculateMACD, calculateBollingerBands } from './services/indicators.js';
import newsRoutes from './routes/news.js';

import compression from 'compression';

const app = express();
const PORT = 3000;

app.use(cors());
app.use(compression()); // Enable gzip compression
app.use(express.json());

// Register Routes
console.log('Registering /api/news route...');
console.log('newsRoutes type:', typeof newsRoutes);
console.log('newsRoutes:', newsRoutes);
app.use('/api/news', newsRoutes);
app.get('/api/test', (req, res) => res.send('Test working'));
console.log('Route registered.');

// Initial fetch
updateMarketData();

// Schedule updates every 1 minute
cron.schedule('* * * * *', () => {
    updateMarketData();
});

// Endpoints

app.get('/api/market', (req, res) => {
    const repo = getRepository();
    // Optimize payload: Only send last 60 points for sparkline and only necessary fields
    const optimizedItems = repo.items.map(item => ({
        ...item,
        sparkline: item.sparkline ? item.sparkline.slice(-60).map((p: any) => ({
            price: p.price || p.close,
            date: p.date
        })) : []
    }));
    res.json(optimizedItems);
});

app.get('/api/history/:symbol', async (req, res) => {
    const { symbol } = req.params;
    let yahooSymbol = symbol;
    if (!['AAPL', 'TSLA', 'MSFT', 'GOOGL', 'AMZN', 'NVDA'].includes(symbol)) {
        if (!symbol.includes('-USD')) yahooSymbol += '-USD';
    }

    const history = await fetchHistory(yahooSymbol);
    res.json(history);
});

app.get('/api/history/:symbol/:interval', async (req, res) => {
    const { symbol, interval } = req.params;
    let yahooSymbol = symbol;
    if (!['AAPL', 'TSLA', 'MSFT', 'GOOGL', 'AMZN', 'NVDA'].includes(symbol)) {
        if (!symbol.includes('-USD')) yahooSymbol += '-USD';
    }

    // Map interval to period
    let period = '1mo'; // Default
    if (interval === '1m') period = '7d';
    if (interval === '5m') period = '60d';
    if (interval === '15m') period = '60d';
    if (interval === '1h') period = '730d';
    if (interval === '3h') period = '730d';
    if (interval === '1d') period = '5y';

    try {
        const history = await fetchHistory(yahooSymbol, interval);
        res.json(history);
    } catch (error) {
        console.error(`Error fetching history for ${symbol}:`, error);
        res.status(500).json({ error: 'Failed to fetch history' });
    }
});

app.get('/api/indicators/:symbol', async (req, res) => {
    const { symbol } = req.params;
    const { interval } = req.query; // Get interval from query params
    const queryInterval = (interval as string) || '1d'; // Default to 1d

    let yahooSymbol = symbol;
    if (!['AAPL', 'TSLA', 'MSFT', 'GOOGL', 'AMZN', 'NVDA'].includes(symbol)) {
        if (!symbol.includes('-USD')) yahooSymbol += '-USD';
    }

    try {
        // Fetch history with the requested interval
        const history: any[] = await fetchHistory(yahooSymbol, queryInterval);
        const prices = history.map((h: any) => h.close); // Use close price for indicators

        const rsi = calculateRSI(prices);
        const macd = calculateMACD(prices);
        const bb = calculateBollingerBands(prices);

        // Align data with dates
        const result = history.map((h: any, i: number) => ({
            date: h.date,
            price: h.close, // Use close as price
            open: h.open,
            high: h.high,
            low: h.low,
            close: h.close,
            volume: h.volume,
            rsi: rsi[i],
            macd: macd.macd[i],
            macdSignal: macd.signal[i],
            macdHistogram: macd.histogram[i],
            bbUpper: bb.upper[i],
            bbLower: bb.lower[i],
            bbMiddle: bb.middle[i]
        }));

        res.json(result);
    } catch (error) {
        console.error(`Error calculating indicators for ${symbol}:`, error);
        res.status(500).json({ error: 'Failed to calculate indicators' });
    }
});

app.get('/api/fundamentals/:symbol', async (req, res) => {
    const { symbol } = req.params;
    let yahooSymbol = symbol;
    if (!['AAPL', 'TSLA', 'MSFT', 'GOOGL', 'AMZN', 'NVDA'].includes(symbol)) {
        if (!symbol.includes('-USD')) yahooSymbol += '-USD';
    }

    try {
        const yf = new yahooFinance();
        const summary = await yf.quoteSummary(yahooSymbol, {
            modules: ['summaryDetail', 'financialData', 'defaultKeyStatistics', 'assetProfile']
        });
        res.json(summary);
    } catch (error: any) {
        console.error(`Error fetching fundamentals for ${symbol}:`, error);
        res.status(500).json({ error: 'Failed to fetch fundamentals', details: error.message });
    }
});

// Auth & Rating Endpoints

app.post('/api/register', (req, res) => {
    const { username, password, email } = req.body;
    // Get IP address
    const ip = req.ip || req.connection.remoteAddress || 'unknown';

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password required' });
    }

    if (getUser(username)) {
        return res.status(400).json({ error: 'Username already exists' });
    }

    // Check IP Limit
    const usersOnIp = getUsersByIp(String(ip));
    if (usersOnIp.length >= 4) {
        return res.status(403).json({ error: 'Registration limit reached for this IP address (Max 4 accounts).' });
    }

    const INITIAL_GAME_STATE = {
        balance: 10000,
        loan: 0,
        portfolio: [],
        leveragedPositions: [],
        shortPositions: [],
        orders: [],
        skills: {
            stopLossMaster: false,
            leverageTrading: false,
            shortSelling: false,
            multiTimeframe: false,
            dayTrader: false,
            technicalAnalyst: false,
            fundamentalAnalyst: false,
            portfolioManager: false,
            marketTimer: false,
            riskManager: false,
            newsAlert: false,
            insiderInfo: false
        },
        lastLogin: null,
        skillPoints: 8,
        tradesToday: 0,
        lastTradeDate: null
    };

    const newUser = {
        id: Math.random().toString(36).substring(2, 15),
        username,
        password,
        ip: String(ip),
        email: email || '',
        gameState: INITIAL_GAME_STATE,
        portfolioValue: 10000,
        lastActive: new Date().toISOString()
    };

    createUser(newUser);
    res.json({ success: true, user: { id: newUser.id, username: newUser.username, portfolioValue: newUser.portfolioValue, gameState: newUser.gameState } });
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const user = getUser(username);

    if (!user || user.password !== password) {
        return res.status(401).json({ error: 'Invalid credentials' });
    }

    res.json({ success: true, user: { id: user.id, username: user.username, portfolioValue: user.portfolioValue, gameState: user.gameState } });
});

app.post('/api/sync', (req, res) => {
    const { username, gameState } = req.body;
    if (!username || !gameState) {
        return res.status(400).json({ error: 'Missing data' });
    }

    // Update portfolio value for leaderboard
    const portfolioValue = gameState.balance + (gameState.portfolio ? gameState.portfolio.reduce((acc: number, item: any) => acc + (item.amount * item.avgPrice), 0) : 0);

    updateUser(username, {
        gameState,
        portfolioValue: gameState.netWorth || portfolioValue,
        lastActive: new Date().toISOString()
    });

    res.json({ success: true });
});

app.post('/api/recover', (req, res) => {
    const { username, email, newPassword } = req.body;
    const user = getUser(username);

    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    if (user.email && user.email !== email) {
        return res.status(403).json({ error: 'Email does not match records' });
    }

    if (!user.email) {
        return res.status(400).json({ error: 'No recovery email set for this account. Cannot reset.' });
    }

    updateUser(username, { password: newPassword });
    res.json({ success: true, message: 'Password reset successfully' });
});

app.post('/api/update-score', (req, res) => {
    const { username, portfolioValue } = req.body;
    if (!username || portfolioValue === undefined) {
        return res.status(400).json({ error: 'Missing data' });
    }

    updateUser(username, {
        portfolioValue: Number(portfolioValue),
        lastActive: new Date().toISOString()
    });

    res.json({ success: true });
});

app.get('/api/leaderboard', (req, res) => {
    const users = getUsers();
    const leaderboard = users
        .sort((a, b) => b.portfolioValue - a.portfolioValue)
        .map(u => ({
            username: u.username,
            portfolioValue: u.portfolioValue
        }));

    res.json(leaderboard);
});

// Listen on all network interfaces (0.0.0.0)
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Backend server running on http://localhost:${PORT}`);
    console.log(`Mobile devices can connect to: http://192.168.1.182:${PORT}`);
});
