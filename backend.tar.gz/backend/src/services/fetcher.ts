import YahooFinance from 'yahoo-finance2';
import { getRepository, saveRepository } from './storage.js';

// Create Yahoo Finance instance
const yahooFinance = new YahooFinance();
const SYMBOLS = [
    'BTC-USD', 'ETH-USD', 'SOL-USD', 'DOGE-USD', // Crypto
    'AAPL', 'TSLA', 'MSFT', 'GOOGL', 'AMZN', 'NVDA' // Stocks
];

export const updateMarketData = async () => {
    console.log('====================================');
    console.log('Fetching market data from Yahoo Finance...');
    console.log(`Symbols to fetch: ${SYMBOLS.join(', ')}`);
    const repo = getRepository();
    const items = [];

    for (const symbol of SYMBOLS) {
        try {
            console.log(`Fetching ${symbol}...`);
            const quoteResult = await yahooFinance.quote(symbol);

            // Optimize history: Append new data instead of re-fetching all
            let history = repo.history[symbol] || [];

            if (history.length === 0) {
                // Initial fetch if empty
                history = await fetchHistory(symbol);
            } else {
                // Append new data point if it's new
                const lastPoint = history[history.length - 1];
                const newTime = quoteResult.regularMarketTime ? new Date(quoteResult.regularMarketTime).toISOString() : new Date().toISOString();

                // Only append if time is different (and newer)
                // Note: regularMarketTime might not change if market is closed
                if (lastPoint && lastPoint.date !== newTime) {
                    console.log(`Appending new data point for ${symbol}: ${newTime}`);
                    history.push({
                        date: newTime,
                        open: quoteResult.regularMarketPrice,
                        high: quoteResult.regularMarketPrice,
                        low: quoteResult.regularMarketPrice,
                        close: quoteResult.regularMarketPrice,
                        volume: 0, // Volume not always available in quote
                        price: quoteResult.regularMarketPrice
                    });

                    // Limit size to prevent memory overload (keep last 300 points)
                    if (history.length > 300) {
                        history = history.slice(-300);
                    }

                    // Update repo
                    repo.history[symbol] = history;
                    saveRepository(repo);
                }
            }

            const item = {
                id: symbol,
                symbol: symbol.replace('-USD', ''),
                name: quoteResult.shortName || quoteResult.longName || symbol,
                price: quoteResult.regularMarketPrice,
                change24h: quoteResult.regularMarketChangePercent,
                type: symbol.includes('-USD') ? 'crypto' : 'stock',
                sparkline: history
            };
            items.push(item);
            console.log(`✓ ${symbol}: $${item.price} (${item.change24h?.toFixed(2)}%)`);
        } catch (error) {
            console.error(`✗ Error fetching ${symbol}:`, error instanceof Error ? error.message : error);
        }
    }

    repo.items = items;
    repo.lastUpdated = new Date().toISOString();
    saveRepository(repo);
    console.log(`Market data updated. Total items: ${items.length}/10`);
    console.log('====================================');
};

export const fetchHistory = async (symbol: string, interval: string = '5m') => {
    const repo = getRepository();

    try {
        // Map interval to appropriate range/period
        let periodDays = 1;
        switch (interval) {
            case '1m': periodDays = 2; break; // 1m needs short range (max 7 days)
            case '5m': periodDays = 1; break;
            case '15m': periodDays = 5; break;
            case '1h': periodDays = 30; break;
            case '3h': periodDays = 60; break; // 3h isn't standard yahoo, might need fallback or use 1h and aggregate? Yahoo supports 60m, 1d. Let's try 1h for now or check valid intervals.
            // Valid yahoo intervals: 1m, 2m, 5m, 15m, 30m, 60m, 90m, 1h, 1d, 5d, 1wk, 1mo, 3mo
            case '1d': periodDays = 365; break;
            default: periodDays = 1;
        }

        // Yahoo Finance API requires specific interval strings
        // Map '3h' to '1h' if '3h' is not supported, or handle it. Yahoo doesn't support '3h'.
        // We will use '1h' for '3h' request and let frontend handle display or just use '1h'.
        // Actually, let's stick to supported intervals: 1m, 15m, 1h, 1d.
        // If user asks for 3h, we'll fetch 1h and maybe frontend can skip points, or we just return 1h data.
        let queryInterval: any = interval;
        if (interval === '3h') queryInterval = '1h';

        let queryOptions: any = {
            period1: new Date(Date.now() - periodDays * 24 * 60 * 60 * 1000),
            interval: queryInterval
        };

        let result: any = await yahooFinance.chart(symbol, queryOptions);

        // Fallback logic for empty data (e.g. weekend/closed market)
        if (!result.quotes || result.quotes.length === 0) {
            console.log(`No data for ${symbol} with interval ${interval}, extending range...`);
            // Extend range significantly
            queryOptions.period1 = new Date(Date.now() - (periodDays * 3) * 24 * 60 * 60 * 1000);
            result = await yahooFinance.chart(symbol, queryOptions);
        }

        const historyData = result.quotes
            .filter((q: any) => q.close !== null && q.close !== undefined)
            .map((q: any) => ({
                date: q.date.toISOString(),
                open: q.open,
                high: q.high,
                low: q.low,
                close: q.close,
                volume: q.volume,
                price: q.close // Keep price for backward compatibility
            }));

        // If we got no data, return empty (or cache if it matches default)
        if (historyData.length === 0) {
            console.log(`Warning: No history data found for ${symbol} (${interval})`);
            // Only return cache if it's the default 5m view, otherwise return empty for specific intervals
            if (interval === '5m') return repo.history[symbol] || [];
            return [];
        }

        // For default 5m, update cache
        if (interval === '5m') {
            repo.history[symbol] = historyData.slice(-100); // Keep last 100 for sparklines
            saveRepository(repo);
        }

        return historyData;
    } catch (error) {
        console.error(`Error fetching history for ${symbol} (${interval}):`, error);
        if (interval === '5m') return repo.history[symbol] || [];
        return [];
    }
};
