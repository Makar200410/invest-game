import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_FILE = path.join(__dirname, '../market_repository.json');

export interface User {
    id: string;
    username: string;
    password: string; // In a real app, this should be hashed!
    ip: string;
    email?: string;
    gameState: any; // Full serialized game state
    portfolioValue: number; // Kept for leaderboard efficiency
    lastActive: string;
}

export interface MarketData {
    lastUpdated: string;
    items: any[];
    history: Record<string, any[]>; // Cache for historical data
    users: User[];
}

// Initialize empty repository if not exists
if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ lastUpdated: '', items: [], history: {}, users: [] }, null, 2));
}

export const getRepository = (): MarketData => {
    try {
        const data = fs.readFileSync(DATA_FILE, 'utf-8');
        const parsed = JSON.parse(data);
        // Ensure users array exists (migration for existing file)
        if (!parsed.users) parsed.users = [];
        return parsed;
    } catch (error) {
        console.error('Error reading repository:', error);
        return { lastUpdated: '', items: [], history: {}, users: [] };
    }
};

export const saveRepository = (data: MarketData) => {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Error saving repository:', error);
    }
};

// User helper functions
export const getUsers = (): User[] => {
    return getRepository().users;
};

export const getUser = (username: string): User | undefined => {
    return getRepository().users.find(u => u.username === username);
};

export const getUsersByIp = (ip: string): User[] => {
    return getRepository().users.filter(u => u.ip === ip);
};

export const createUser = (user: User): void => {
    const repo = getRepository();
    repo.users.push(user);
    saveRepository(repo);
};

export const updateUser = (username: string, updates: Partial<User>): void => {
    const repo = getRepository();
    const index = repo.users.findIndex(u => u.username === username);
    if (index !== -1) {
        repo.users[index] = { ...repo.users[index], ...updates };
        saveRepository(repo);
    }
};
